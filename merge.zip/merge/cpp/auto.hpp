#ifndef AUTO
#define AUTO

#include "./rules.hpp"

struct vpos
{
    int a[mx][mx], n, m;
    vpos(pos P)
    {
        n=P.n, m=P.m;
        for(int i=0; i<n; i++) for(int j=0; j<n; j++) a[i][j]=P.a[i][j];
    }
};
namespace comp
{
    int n;
    mt19937 rng(time(0));
}
namespace comp0
{
}
namespace comp1
{
    gp_hash_table<ull,int> dp;
    int dfs(vector<int> a[])
    {
        ull h=123; for(int i=0; i<mx; i++) for(int j=0; j<a[i].size(); j++)
            h=(h<<8)^(h>>5)^a[i][j]^(47*i+61*j);
        if(comp1::dp.find(h)!=comp1::dp.end()) return comp1::dp[h];
        int ans=0; for(int i=0; i<mx; i++) ans+=a[i].size();
        for(int i=0; i<mx; i++) for(int j=0; j<a[i].size(); j++)
        {
            vector<pi> v(1,pi(i,j)); int C=a[i][j], k=0; vector<int> b[mx], c[mx];
            for(int x=0; x<mx; x++) b[x]=a[x];
            while(!v.empty())
            {
                pi p=v.back(); v.pop_back(); if(b[p.f][p.s]!=C) continue;
                k++, b[p.f][p.s]=-1;
                if(p.f) if(p.s<b[p.f-1].size()) v.pb(pi(p.f-1,p.s));
                if(p.f<mx-1) if(p.s<b[p.f+1].size()) v.pb(pi(p.f+1,p.s));
                if(p.s) v.pb(pi(p.f,p.s-1)); if(p.s<b[p.f].size()-1) v.pb(pi(p.f,p.s+1));
            }
            if(k==1) continue; b[i][j]=++C;
            for(int x=0; x<mx; x++) for(int t:b[x]) if(t!=-1) c[x].pb(t);
            ans=min(ans,dfs(c));
        }
        return comp1::dp[h]=ans;
    }
}
namespace comp2
{
}
namespace comp3
{
}
namespace comp4
{
}
pi(*comps[5])(vpos){
//0: Random
[](vpos P)
{
    comp::n=P.n;
    while(1)
    {
        int x=comp::rng()%comp::n, y=comp::rng()%comp::n, d=comp::rng()%4;
        if(d==0) if(x) if(P.a[x-1][y]==P.a[x][y]) return pi(x,y);
        if(d==1) if(x!=comp::n-1) if(P.a[x+1][y]==P.a[x][y]) return pi(x,y);
        if(d==2) if(y) if(P.a[x][y-1]==P.a[x][y]) return pi(x,y);
        if(d==3) if(y!=comp::n-1) if(P.a[x][y+1]==P.a[x][y]) return pi(x,y);
    }
},
//1: Greedy (4x4 J5413, 5x5 L44597)
[](vpos P)
{
    comp::n=P.n, comp1::dp.clear(); int best=comp::n*comp::n; vector<pi> ans;
    for(int i=0; i<comp::n; i++) for(int j=0; j<comp::n; j++)
    {
        vector<pi> v(1,pi(i,j)); int C=P.a[comp::n-1-j][i], k=0; vector<int> b[mx], c[mx];
        for(int x=0; x<comp::n; x++) for(int y=comp::n-1; y>=0; y--) b[x].pb(P.a[y][x]);
        while(!v.empty())
        {
            pi p=v.back(); v.pop_back(); if(b[p.f][p.s]!=C) continue;
            k++, b[p.f][p.s]=-1;
            if(p.f) v.pb(pi(p.f-1,p.s)); if(p.f<comp::n-1) v.pb(pi(p.f+1,p.s));
            if(p.s) v.pb(pi(p.f,p.s-1)); if(p.s<comp::n-1) v.pb(pi(p.f,p.s+1));
        }
        if(k==1) continue; b[i][j]=++C;
        for(int x=0; x<mx; x++) for(int t:b[x]) if(t!=-1) c[x].pb(t);
        k=comp1::dfs(c); if(k<best) ans.clear(), best=k; if(k==best) ans.pb(pi(comp::n-1-j,i));
    }
    return ans[comp::rng()%ans.size()];
},
//2: Silhouettes
0,
//3: MCTS speedup of greedy
0,
//4: 
0
};

#endif
