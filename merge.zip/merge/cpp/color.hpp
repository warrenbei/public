#ifndef COLOR
#define COLOR

#include "./includes.hpp"
int col[ncol],
R[]{
255,    192,    128,    64,
0,      0,      0,      0,
0,      64,     128,    192,
64,     128,     192,    255},
G[]{
0,      64,     128,    192,
255,    192,    128,    64,
0,      0,      0,      0,
64,     128,     192,    255},
B[]{
0,      0,      0,      0,
0,      64,     128,    192,
255,    192,    128,    64,
64,     128,     192,    255};
void init_color()
{
    for(int i=0; i<ncol; i++) init_color(i+16,R[i],G[i],B[i]),
        init_pair(i+16,i+16,0), col[i]=COLOR_PAIR(i+16);
}

#endif
