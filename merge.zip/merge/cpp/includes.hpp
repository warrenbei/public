#ifndef INCLUDES
#define INCLUDES

#include <assert.h>
#include <iostream>
#include <fstream>
#include <ncurses.h>
#include <cstring>
#include <random>
#include <chrono>
#include <thread>
#include <vector>
#include <ext/pb_ds/assoc_container.hpp>
using namespace std;
using namespace __gnu_pbds;
typedef unsigned long long ull;
typedef pair<int,int> pi;
#define f first
#define s second
#define pb push_back
#define mx 8
#define ncol 16

#endif
