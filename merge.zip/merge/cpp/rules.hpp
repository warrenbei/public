#ifndef RULES
#define RULES

#include "./includes.hpp"

double incr_prob(int n, int m) {return 0.6-n/30.0;}
struct pos
{
    int a[mx][mx], n, m, S; vector<pi> save;
    ull sd; mt19937 rng; uniform_real_distribution<double> gen;
    pos(int N=5, ull seed=time(0))
    {
        n=N, sd=seed, rng.seed(sd), m=S=0;
        for(int i=0; i<n; i++) for(int j=0; j<n; j++) a[i][j]=0;
    }
    bool lost()
    {
        for(int i=0; i<n; i++) for(int j=1; j<n; j++)
            if(a[i][j]==a[i][j-1] or a[j][i]==a[j-1][i]) return 0;
        return 1;
    }
    /*
    0: success
    1: component size 1
    2: invalid input
    3: win
    */
    int move(int x, int y)
    {
        if(x<0 or x>=n or y<0 or y>=n) return 2;
        vector<pi> v(1,pi(x,y)); int C=a[x][y], k=0;
        while(!v.empty())
        {
            pi p=v.back(); v.pop_back(); if(a[p.f][p.s]!=C) continue;
            k++, a[p.f][p.s]=-1;
            if(p.f) v.pb(pi(p.f-1,p.s)); if(p.f<n-1) v.pb(pi(p.f+1,p.s));
            if(p.s) v.pb(pi(p.f,p.s-1)); if(p.s<n-1) v.pb(pi(p.f,p.s+1));
        }
        if(k==1) {a[x][y]=C; return 1;}
        save.pb(pi(x,y)), S+=k<<C, a[x][y]=++C, m=max(m,C);
        for(int j=0; j<n; j++) for(int i=n-1, l=n-1; i>=0; i--)
            if(a[i][j]!=-1) {if(i!=l) a[l][j]=a[i][j], a[i][j]=-1; l--;}
        for(int i=0; i<n; i++) for(int j=0; j<n; j++) if(a[i][j]==-1)
        {
            retry: a[i][j]=0;
            while(a[i][j]<m) if(gen(rng)<incr_prob(a[i][j],m)) a[i][j]++; else break;
            if(a[i][j]==m) goto retry;
        }
        return m==ncol?3:0;
    }
    string record()
    {
        string ans=to_string(n); ans+='\n', ans+=to_string(sd), ans+='\n';
        ans+=char('A'+m), ans+=to_string(S), ans+='\n';
        for(pi p:save) ans+=char('A'+p.f), ans+=to_string(p.s+1), ans+=' ';
        return ans+'\n';
    }
};

#endif
