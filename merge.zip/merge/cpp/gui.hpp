#ifndef GUI
#define GUI

#include "./color.hpp"
#include "./rules.hpp"
#include "./auto.hpp"

/*
0: play
1: computer
2: view
3: view (auto)
*/
namespace guic
{
    chrono::milliseconds delay(500);
    ifstream fsave;
    pi(*compf)(vpos);
    ull cseed=time(0);
}
string gui(int n, ull seed, int mode)
{
    if(mode==2 or mode==3)
    {string S1, S2, S3; guic::fsave>>S1>>S2>>S3, n=stoi(S1), seed=stoull(S2);}
    if(mode==1) comp::rng.seed(guic::cseed);
    initscr(),cbreak(),noecho(),curs_set(0),start_color(),init_color();
    pos P(n,seed); int x=0, y=0, c;
    for(int i=0; i<n; i++)
    {
        for(int j=0; j<n; j++) addstr("+-"); addstr("+\n");
        for(int j=0; j<n; j++) addstr("| "); addstr("|\n");
    }
    for(int i=0; i<n; i++) addstr("+-"); addch('+');
    while(1)
    {
        for(int i=0; i<n; i++) for(int j=0; j<n; j++) mvaddch(i*2+1,j*2+1,
            ('A'+P.a[i][j])|((i==x&&j==y)?A_STANDOUT:((i==x|j==y)?A_BOLD:0))|col[P.a[i][j]]);
        mvaddstr(2*n+1,2,(char('A'+P.m)+to_string(P.S)).c_str()), refresh();
        if(mode==0)
        {
            c=getch();
            if(c=='Q') goto ended; if(c==' ') if(P.move(x,y)==3) goto ended;
            if(c=='w') x=max(0,x-1); if(c=='s') x=min(n-1,x+1);
            if(c=='a') y=max(0,y-1); if(c=='d') y=min(n-1,y+1);
            if(c=='W') x=0; if(c=='S') x=n-1; if(c=='A') y=0; if(c=='D') y=n-1;
            continue;
        }
        else if(mode==1)
        {
            if(P.lost()) goto ended; pi p=guic::compf(vpos(P)); x=p.f, y=p.s;
            this_thread::sleep_for(guic::delay); if(P.move(x,y)==3) goto ended;
            continue;
        }
        else if(mode==2)
        {
            char C; guic::fsave>>C>>y, x=C-'A', y--;
            c=getch(); if(c=='Q') goto ended; if(P.move(x,y)==3) goto ended;
            continue;
        }
        else if(mode==3)
        {
            char C; guic::fsave>>C>>y, x=C-'A', y--;
            this_thread::sleep_for(guic::delay); if(P.move(x,y)==3) goto ended;
            continue;
        }
        ended: endwin(); return P.record();
    }
}

#endif
