#include "./gui.hpp"

string help="\
Usage: ./merge_gui\n\
    h -- help\n\
    p <n> <seed> -- play\n\
    l <file> -- view replay\n\
    v <file> <delay> -- automatic replay\n\
    c <cnum> <n> <delay> <seed> <cseed> -- watch computer\n\
Defaults:\n\
    n       5\n\
    seed    time(0)\n\
    delay   500ms\n\
    cnum    0\n\
    cseed   time(0)\n\
";

int main(int argc, char *argv[])
{
    int n=5, cnum=0; ull seed=time(0);
    if(argc==1) goto invalid;
    if(!strcmp(argv[1],"h")) goto invalid;
    if(!strcmp(argv[1],"p"))
    {
        if(argc>=3) n=stoi(argv[2]);
        if(argc>=4) seed=stoull(argv[3]);
        cout<<gui(n,seed,0), exit(0);
    }
    if(!strcmp(argv[1],"l"))
    {
        if(argc==2) goto invalid;
        guic::fsave.open(argv[2]), gui(0,0,2), exit(0);
    }
    if(!strcmp(argv[1],"v"))
    {
        if(argc==2) goto invalid;
        if(argc>=4) guic::delay=chrono::milliseconds(stoi(argv[3]));
        guic::fsave.open(argv[2]), gui(0,0,3), exit(0);
    }
    if(!strcmp(argv[1],"c"))
    {
        if(argc>=3) cnum=stoi(argv[2]);
        if(argc>=4) n=stoi(argv[3]);
        if(argc>=5) guic::delay=chrono::milliseconds(stoi(argv[4]));
        if(argc>=6) seed=stoull(argv[5]);
        if(argc>=7) guic::cseed=stoull(argv[6]);
        guic::compf=comps[cnum], cout<<gui(n,seed,1), exit(0);
    }
    invalid: cout<<help, exit(0);
}
