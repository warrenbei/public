#include <iostream>
#include <ncurses.h>
#include <random>
#include <vector>
using namespace std; typedef pair<int,int> pi;
#define f first
#define s second
#define pb push_back
int a[6][6],m,S,x,y,c,col[16],
R[16]{
255,    192,    128,    64,
0,      0,      0,      0,
0,      64,     128,    192,
64,     128,     192,    255},
G[16]{
0,      64,     128,    192,
255,    192,    128,    64,
0,      0,      0,      0,
64,     128,     192,    255},
B[16]{
0,      0,      0,      0,
0,      64,     128,    192,
255,    192,    128,    64,
64,     128,     192,    255};
int main()
{
    initscr(),cbreak(),noecho(),curs_set(0),start_color();
    mt19937 rng(time(0)); uniform_real_distribution<double> gen;
    for(int i=0; i<6; i++) addstr("+-+-+-+-+-+-+\n| | | | | | |\n"); addstr("+-+-+-+-+-+-+");
    for(int i=0; i<16; i++) init_color(i+16,R[i],G[i],B[i]), init_pair(i+16,i+16,0), col[i]=COLOR_PAIR(i+16);
    while(1)
    {
        for(int i=0; i<6; i++) for(int j=0; j<6; j++)
            mvaddch(i*2+1,j*2+1,('A'+a[i][j])|((i==x&&j==y)?A_STANDOUT:((i==x|j==y)?A_BOLD:0))|col[a[i][j]]);
        mvaddstr(13,2,(char('A'+m)+to_string(S)).c_str()), refresh(), c=getch();
        if(c=='Q') endwin(), cout<<"Terminated at "<<char('A'+m)<<S<<'\n', exit(0);
        if(c=='w') x=max(0,x-1); if(c=='s') x=min(5,x+1); if(c=='a') y=max(0,y-1); if(c=='d') y=min(5,y+1);
        if(c=='W') x=0; if(c=='S') x=5; if(c=='A') y=0; if(c=='D') y=5;
        if(c==' ')
        {
            vector<pi> v(1,pi(x,y)); int C=a[x][y], k=0; pi p;
            while(!v.empty()) {p=v.back(), v.pop_back(); if (a[p.f][p.s]!=C) continue; k++, a[p.f][p.s]=-1;
                if(p.f) v.pb(pi(p.f-1,p.s)); if(p.f<5) v.pb(pi(p.f+1,p.s));
                if(p.s) v.pb(pi(p.f,p.s-1)); if(p.s<5) v.pb(pi(p.f,p.s+1));}
            if (k==1) {a[x][y]=C; goto loop_exit;} S+=k<<C, a[x][y]=++C, m=max(m,C);
            for(int j=0; j<6; j++) for(int i=5, l=5; i>=0; i--)
                if(a[i][j]!=-1) {if(i!=l) a[l][j]=a[i][j], a[i][j]=-1; l--;}
            for(int i=0; i<6; i++) for(int j=0; j<6; j++) if(a[i][j]==-1) {retry: a[i][j]=0; while(a[i][j]<m)
                if(gen(rng)<0.6-a[i][j]/30.0) a[i][j]++; else break; if(a[i][j]==m) goto retry;}
            if (C==16) {endwin(), cout<<"You win, score "<<S<<'\n', exit(0);} loop_exit:;
        }
    }
}